const categoryColors = {
    'Tech Culture' : 'rgb(255, 59, 48)',
    'Tech News' : 'rgb(0, 113, 104)',
    'Brain Health' : 'rgb(175, 82, 250)',
    'React' : 'rgb(64, 156, 255)',
    'Cloud' : 'rgb(90, 200, 250)',
    'Databases': 'rgb(0, 113,164)',
    'Javascript' : 'rgb(255,179,54)',
    'SQL' : 'rgb(48, 209, 88)',
    'NoSQL' : 'rgb(255, 149, 0)',
}
export default  categoryColors