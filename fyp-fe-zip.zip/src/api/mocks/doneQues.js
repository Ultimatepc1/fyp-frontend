export default[{
    cardName: 'Get request to return a string in json format',
    cardDescription: 'Description',
    // cardTotal: 0,
    // showBodyImage: true,
    // bodyImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/640px-Image_created_with_a_mobile_phone.png'
}, {
    cardName: 'Get request to return a list',
    cardDescription: 'Description 2',
    // cardTotal: 1
}, ]