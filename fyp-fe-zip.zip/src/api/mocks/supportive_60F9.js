export default [
    {
        'id' : '1',
        'resource_no': 1,
        // 'url': 'https://medium.com/@etiennerouzeaud/how-create-an-api-restfull-in-express-node-js-without-database-b030c687e2ea'
        // 'url':'https://stackoverflow.com/questions/30276339/restful-api-without-database-connection',
        'url':'https://www.edureka.co/blog/rest-api-with-node-js/',
    },
    {
        'id' : '1',
        'resource_no': 2,
        'url': 'https://dotnettutorials.net/lesson/get-method-in-web-api/'
    },
    {
        'id' : '2',
        'resource_no': 3,
        'url': 'https://www.tutorialsteacher.com/webapi/implement-get-method-in-web-api'
    },
    {
        'id' : '2',
        'resource_no': 4,
        'url': 'https://blog.dreamfactory.com/7-simple-rest-client-examples-for-retrieving-api-data/'
    },

    {
        'id' : '3',
        'resource_no': 5,
        'url': 'https://www.tutorialspoint.com/expressjs/expressjs_url_building.htm'
    },
    {
        'id' : '4',
        'resource_no': 6,
        'url': 'https://www.moesif.com/blog/technical/api-design/REST-API-Design-Best-Practices-for-Parameters-and-Query-String-Usage/'
    },
    {
        'id' : '4',
        'resource_no': 7,
        'url': 'https://www.toolsqa.com/rest-assured/query-parameters-in-rest-assured/'
    },
    {
        'id' : '5',
        'resource_no': 8,
        'url': 'https://developer.atlassian.com/server/confluence/pagination-in-the-rest-api/'
    },
    {
        'id' : '6',
        'resource_no': 9,
        'url': 'https://developer.sas.com/reference/filtering/'
    }
]