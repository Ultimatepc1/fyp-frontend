export default {
    id: 'bnjdbjfbdj',
    title: 'Get Request Without DB',
    question: 'ijidcfiefiedifeifiejfijdeif',
    example: [
        {
            sample_input: 'enjfcnekdneikdc',
            sample_output: 'ebhnfcdjuebcjbedcjdebjc'
        },
        {
            sample_input: 'enjfcnekdneikdc',
            sample_output: 'ebhnfcdjuebcjbedcjdebjc'
        }
    ],
    ide:"https://codesandbox.io/embed/node-express-rest-template-ihc9g?autoresize=1&codemirror=1&expanddevtools=1&fontsize=14&hidenavigation=1&moduleview=1&theme=dark&forcerefresh=1"
}
