import React from 'react'

export default function Blog(){
    return(
        <div>Blog</div>
    );
}